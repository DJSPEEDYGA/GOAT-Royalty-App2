window.addEventListener('DOMContentLoaded', () => {
  console.log('Preload script loaded');
});