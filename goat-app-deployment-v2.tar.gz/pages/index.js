import GOATRoyaltyAppEnhanced from '../components/GOATRoyaltyAppEnhanced';
export default function Home() {
  return <GOATRoyaltyAppEnhanced />;
}
